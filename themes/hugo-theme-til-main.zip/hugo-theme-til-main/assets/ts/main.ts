import ContentNetworkGraph from './components/ContentNetworkGraph';
import ClipboardCopier from './components/ClipboardCopier';

customElements.define('content-network-graph', ContentNetworkGraph);
customElements.define('clipboard-copy', ClipboardCopier);
